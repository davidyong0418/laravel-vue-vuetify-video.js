<h1>Hi, {{$name}}</h1>

<span>Password is &nbsp;</span><h4>{{$password}}</h4>