<template>
  <v-parallax
    dark
    src="https://cdn.vuetifyjs.com/images/backgrounds/vbanner.jpg"
  >
    <v-layout
      align-center
      column
      justify-center
    >
      <h1 class="display-2 font-weight-thin mb-3">Answer and Question System</h1>
      <h4 class="subheading">Enjoy your system!</h4>
    </v-layout>
  </v-parallax>
</template>

<script>
  export default {
    data () {
      return {
      }
    }
  }
</script>