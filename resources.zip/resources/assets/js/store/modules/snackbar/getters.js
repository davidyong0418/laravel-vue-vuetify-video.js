export default {
  snackbarShow: state => state.show,
  snackbarColor: state => state.color,
  snackbarText: state => state.text,
  snackbarSubtext: state => state.subText,
  snackbarTimeout: state => state.timeout
}
